/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
Algorithm
Parse a scentance word by word.
On detection of a keyword check previous or next word for consonant of code
for e.g generate function abc implies function keyword and abc as consonant of the code

example syntax to speak :
generate function abc that has 3 int parameters and returns int
generate function abc that has 1 float parameter and returns float
generate function abc that has 0 parameters and returns void

generate class abc with 3 public/private/protected variables.  

generate loop for 10 iterations. 


*/
package code_generation;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import static java.lang.Integer.parseInt;
import java.util.Scanner;

public class Code_generation {

    
    public static void main(String[] args) throws FileNotFoundException, IOException {
        System.out.println("Please Enter the sentence");
        Scanner sc = new Scanner(System.in);
        String s= sc.nextLine();
        String[] word = s.split(" ");
        System.out.println("la"+word[1]);
        switch (word[1]){
            case "function":
            {
                System.out.println("Printing a function");
                create_function(word);
                break;
            }
            case "class":{
                System.out.println("Printing a Class");
                
                break;
            }
                
        }
       //  
        
    }

    private static void create_function(String[] word) throws FileNotFoundException, IOException {
                String name=word[2];            //name of function
                String count_parameter= word[5];
               int count= parseInt(count_parameter);int i=0;
                String parameter_datatype= word[6];
                String return_type=word[word.length-1];
                BufferedReader filein =new BufferedReader(new FileReader("C:\\Users\\shons\\OneDrive\\Documents\\NetBeansProjects\\Code_generation\\src\\code_generation\\function.txt"));
                String line=filein.readLine();
                String parameter_final="";
                while(i < count){
                    int ascii = 67+i;
                    parameter_final=parameter_final+" "+parameter_datatype+" "+(char)ascii+",";
                    i++;
                }
                parameter_final=parameter_final.substring(0, i-2);
                
                while(line!=null)
                {
                  line.replace("datatype", return_type);  
                  line.replace("name", name);
                  line.replace("parameter", parameter_final);
                  
                  if ("datatype".compareTo("void")==0)
                  {
                      line.replace("return null", "");
                  }
                  
                 
                    System.out.println(line);
                  
                    line=filein.readLine();
                   
                }
                
                
               
    }
    
}
