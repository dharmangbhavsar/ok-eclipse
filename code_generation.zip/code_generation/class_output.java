class SORRY{
srija variables  a, b, c;
SORRY(){
}
} 



